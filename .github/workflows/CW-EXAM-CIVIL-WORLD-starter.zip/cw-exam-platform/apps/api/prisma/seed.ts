import { PrismaClient, Role } from "@prisma/client";
const prisma = new PrismaClient();
async function main() {
  // Intentionally seeds public catalogue examples only. Create a real admin through a secure bootstrap process.
  const categories = [
    { name: "Teaching Exams", slug: "teaching-exams", description: "TGT, PGT, TET and other teaching examinations", sortOrder: 1 },
    { name: "SSC Exams", slug: "ssc-exams", description: "SSC examination preparation", sortOrder: 2 },
    { name: "Railway Exams", slug: "railway-exams", description: "Railway examination preparation", sortOrder: 3 },
    { name: "UPSSSC PET", slug: "upsssc-pet", description: "UPSSSC PET preparation", sortOrder: 4 }
  ];
  for (const category of categories) await prisma.examCategory.upsert({ where: { slug: category.slug }, update: {}, create: { ...category, status: "PUBLISHED" } });
  console.log("Seeded CW Exam category catalogue. No default admin credentials created.");
}
main().finally(() => prisma.$disconnect());
