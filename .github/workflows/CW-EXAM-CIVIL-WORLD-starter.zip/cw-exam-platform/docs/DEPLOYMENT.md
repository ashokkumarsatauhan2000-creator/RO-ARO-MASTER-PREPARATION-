# Deployment checklist

## Local development
1. Install Node.js 20+, npm, and Docker.
2. Copy `.env.example` to `.env` and replace secrets.
3. Run `npm install`.
4. Start PostgreSQL: `docker compose up -d postgres`.
5. Generate Prisma client: `npm run db:generate`.
6. Create initial migration: `npm run db:migrate:dev`.
7. Seed category examples: `npm run db:seed`.
8. Start API/admin/mobile: `npm run dev`.

## Admin
- Open `http://localhost:5173`.
- Set `VITE_API_URL` in `apps/admin/.env.local` if API is not at `http://localhost:4000/api/v1`.
- The starter dashboard intentionally does not create a default admin login. Implement the secure admin bootstrap and authentication flow before exposing any administrative mutation endpoints.

## Mobile
- Set `EXPO_PUBLIC_API_URL` in the mobile environment. On a physical phone, `localhost` refers to the phone itself; use your development computer's LAN IP or deployed HTTPS API URL.
- Run `npm --workspace @cw-exam/mobile run start` and follow Expo instructions.
- Configure real Android/iOS application identifiers, app icons, signing, and EAS credentials before release.

## Production
- Use HTTPS and a managed PostgreSQL database or hardened self-hosted PostgreSQL.
- Replace every development password and secret.
- Restrict CORS to your real admin/app origins.
- Use production-grade object storage for uploaded content and signed access URLs.
- Configure payment provider order creation, signature verification, webhook verification and idempotency before accepting payments.
- Configure OTP/SMS, push notifications, and live streaming providers if needed.
- Set up database backups and perform a restore test.
- Add monitoring, centralized logs, rate limits, security scanning, and incident recovery procedures.
- Publish privacy policy, terms, refund policy, support contacts, and data deletion process.
- Complete end-to-end tests and security review before real student data or payments.

## Important security note
The current API exposes read-only published catalogue endpoints and health status only. Full authenticated CRUD, student sessions, order/payment processing, test attempts/scoring, file upload, and all other production workflows must be implemented and tested before launch. Never expose an unprotected admin mutation API.
