# Feature implementation and acceptance roadmap

This repository is a runnable starter foundation. The following are required before production launch.

## Foundation (starter included)
- Monorepo/workspaces and environment template.
- Expo student UI with navigation and API-backed published catalogue.
- React admin dashboard with live API health and catalogue counts.
- Express API with security middleware and read-only catalogue endpoints.
- Prisma/PostgreSQL domain schema for users, categories, courses, products, orders, payments, tests, attempts, notifications, and audit logs.
- Docker Compose PostgreSQL/API setup and deployment notes.

## P0 — Required before pilot
- Secure authentication and refresh-session lifecycle.
- Secure first-admin bootstrap, RBAC, and authenticated admin CRUD.
- Course/module/lesson management and entitlement checks.
- Student profile, enrollments, and purchases.
- Test attempt lifecycle, answer autosave, server-side timer validation, scoring, and result release.
- Product uploads using private object storage and signed URLs.
- Order and payment integration in gateway test mode, verified webhooks, idempotency, reconciliation, and refunds.
- Automated unit/integration/end-to-end tests.

## P1 — Required before general launch
- Live classes and provider integration.
- Push/in-app notification delivery and scheduling.
- Shipping and physical-book fulfilment.
- Doubt support and ticket assignment.
- Subscriptions/Test Pass, coupons, referral rules.
- Reports, exports, audit log UI, monitoring, backup/restore verification.
- Accessibility, performance, privacy, and security review.

## Acceptance rule
A module is complete only after UI, API, database, authorization, error states, auditability where needed, and automated tests are implemented. A navigation item or placeholder screen is not a completed feature.
