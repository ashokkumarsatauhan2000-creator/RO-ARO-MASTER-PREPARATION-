# CW EXAM – CIVIL WORLD

A monorepo starter for the CW Exam learning platform: Expo student app, React admin dashboard, Express API, and PostgreSQL/Prisma data model.

> This is a functional starter/MVP foundation, not a claim that every production integration is already configured. Payment, SMS/OTP, push notifications, live video, object storage and app-store release require provider accounts and environment variables.

## Requirements
- Node.js 20+
- npm 10+
- Docker + Docker Compose (recommended)

## Quick start (API + PostgreSQL)
1. Copy `.env.example` to `.env` and set a strong `JWT_SECRET`.
2. Run `docker compose up --build`.
3. In another terminal, install root workspace dependencies: `npm install`.
4. Run `npm run db:generate` and `npm run db:migrate` (first migration may be created with `npm run db:migrate:dev`).
5. Start all apps using `npm run dev`.

Ports: API `4000`, Admin `5173`, Mobile Expo dev server (Expo chooses a port).

## Important
- Never commit `.env` or production secrets.
- Create the first admin securely using the seed script / deployment procedure; do not use default production credentials.
- Configure CORS, HTTPS, backups, monitoring, storage, payment webhooks and privacy/legal pages before production.
- API currently includes a safe starter set of endpoints and an extensible Prisma schema. Implement and test each business workflow before accepting real payments or student data.

## Repository
- `apps/mobile`: Expo React Native student application starter.
- `apps/admin`: responsive web admin dashboard starter.
- `apps/api`: Express REST API and Prisma schema.
- `docs`: deployment, security, and feature roadmap.
